<?php
/**
 *Author: Katie Stinson
 *Date: 2/16/23
 *File: population.php
 *Description: json encode fct
 */

require_once ('population.class.php');

//create obj from class

$name = filter_input("GET",  'name', FILTER_SANITIZE_STRING);

$popObj = new Population();
//create new obj to pass through lookup fct
$population = json_encode($popObj->lookup($name));

//encode to json string
echo $population;



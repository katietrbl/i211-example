<?php

/*
 * Author: Louie Zhu
 * Date: 8/21/2020
 * File: index.php
 * Description: site homepage; redirect users to list_movie.php
 * 
 */

header("Location: list_movie.php");
/*
/ Author: your name
/ Date: today's date
/ File: main.js
/ Description: This file contains javascript code that displays a list of countries of a selected continent.
/*

/* Handle window onload event. It creates a selection list of seven continents.
*/
window.onload = function () {
	// load continents from an external json file
    let continents = JSON.parse(loadJSON("continents.json"));

    //create the drop down list for the continents
    let _html_select = "<option selected='selected' disabled='disabled'>Select a Continent </option>";
    for (let continent in continents) {
        _html_select += "<option value='" + continent + "'>" + continents[continent] + "</option>";
    }
    document.getElementById("continents").innerHTML = _html_select;

	
	//load countries data from an external json file.
    

    
	//handle change event of the drop down list and call the display method.
    
}

/* This function takes a json object of countries and a continent as the parameters. 
*  It filters the json document with a continent then appends a row to
*  the div block for each country.
*/
function display(countries, continent) {
    
}
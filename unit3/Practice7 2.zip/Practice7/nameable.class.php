<?php

/**
 * Author: your name
 * Date: today's date
 * Name: nameable.class.php
 * Description: An interface for all nameable objects.
 */


interface Nameable  {
    //abstract methods
    public function getName();
    public function setName($name);
}
?>
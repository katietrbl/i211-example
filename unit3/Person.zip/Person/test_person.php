<?php
/*
 * Author: your name
 * Date: today's date
 * Name: test_person.phpp
 * Description: this client program tests the Person and Student classes.
 */
?>

<!DOCTYPE html>
<html>

    <head>
        <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
        <meta name="author" content="Admin" />

        <title>The Person class and its subclasses</title>
    </head>

    <body>

        <?php
        //add your code here


        ?>

    </body>
</html>
<?php
/**
 *Author: Katie Stinson
 *Date: 2/14/23
 *File: grad_student.class.php
 *Description:
 */

class GradStudent extends Student
{
    //student program
    private $program;


//get
    public function getProgram()
    {
        return $this->program;
    }

//set
    public function setProgram($program)
    {
        $this->program = $program;
    }
}
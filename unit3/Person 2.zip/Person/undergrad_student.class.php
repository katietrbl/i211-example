<?php
/**
 *Author: Katie Stinson
 *Date: 2/14/23
 *File: undergrad_student.class.php
 *Description:
 */

class UndergradStudent extends Student{
    //year in school
    private $status;

    //get
    public function getStatus(){
        return $this->status;
    }
    //set
    public function setStatus($status){
        $this->status = $status;
    }
}